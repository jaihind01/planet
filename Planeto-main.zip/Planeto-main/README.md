# Planeto
it is a space app made in kotlin and android studio to demostrate the working of Recycler view.
